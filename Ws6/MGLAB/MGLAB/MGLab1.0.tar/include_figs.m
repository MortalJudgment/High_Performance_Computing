%INCLUDE_FIGS Graphics figure global variables

% James Bordner and Faisal Saied
% Department of Computer Science
% University of Illinois at Urbana-Champaign
% 10 April 1995

% Parameters

   global main_fig param_fig
   global main_position param_position
